[system programming lecture]
[20181662 이건영]

-project 1 phase 1

myshell.h
        CS:APP3e functions

myshell.c
        <phase1>
        Simple shell can execute the basic internal shell commands. 
        - cd : to navigate the directories in shell
        - ls : listing the directory contents
        - etc...

